from mensajes.hola.saludos import *
from mensajes.adios.despedida import *

saludar()
Saludo()

despedir()
Despedida()